<?php
session_start();
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'user') {
    header('Location: ../index.php');
    exit;
}
require_once '../config.php';

$current_page = basename($_SERVER['PHP_SELF']);

// Count cart items
$cart_count = isset($_SESSION['cart']) ? count($_SESSION['cart']) : 0;
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Customer Dashboard - RMS</title>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="../assets/css/style.css">
    <style>
        .cart-badge {
            background: var(--danger);
            color: white;
            border-radius: 999px;
            padding: 0.125rem 0.5rem;
            font-size: 0.75rem;
            margin-left: 0.5rem;
        }
    </style>
</head>
<body>
    <div class="app-container">
        <!-- Sidebar -->
        <aside class="sidebar">
            <div class="sidebar-header" style="color: var(--secondary);">
                Retail Store
            </div>
            <nav class="sidebar-nav">
                <a href="dashboard.php" class="nav-item <?php echo $current_page == 'dashboard.php' ? 'active' : ''; ?>">Dashboard</a>
                <a href="products.php" class="nav-item <?php echo $current_page == 'products.php' ? 'active' : ''; ?>">Shop Products</a>
                <a href="cart.php" class="nav-item <?php echo $current_page == 'cart.php' ? 'active' : ''; ?>">My Cart <?php if($cart_count > 0) echo "<span class='cart-badge'>$cart_count</span>"; ?></a>
                <a href="orders.php" class="nav-item <?php echo $current_page == 'orders.php' ? 'active' : ''; ?>">My Orders</a>
            </nav>
        </aside>

        <!-- Main Content -->
        <main class="main-content">
            <!-- Topbar -->
            <header class="topbar">
                <div style="display: flex; align-items: center; justify-content: space-between; width: 100%;">
                    <div style="flex:1;">
                        <!-- Optional search or breadcrumbs -->
                    </div>
                    <div style="display: flex; align-items: center; gap: 1rem;">
                        <span style="font-weight: 500;">Welcome, <?php echo htmlspecialchars($_SESSION['username']); ?></span>
                        <a href="../logout.php" class="btn btn-danger" style="padding: 0.5rem 1rem;">Logout</a>
                    </div>
                </div>
            </header>

            <div class="content-wrapper">
