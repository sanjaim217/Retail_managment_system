<?php
include 'user_header.php';

$success_msg = '';
$error_msg = '';

if (!isset($_SESSION['cart'])) {
    $_SESSION['cart'] = [];
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    if (isset($_POST['action'])) {
        if ($_POST['action'] == 'update') {
            $product_id = (int)$_POST['product_id'];
            $quantity = (int)$_POST['quantity'];
            if ($quantity > 0) {
                $_SESSION['cart'][$product_id] = $quantity;
            } else {
                unset($_SESSION['cart'][$product_id]);
            }
        } elseif ($_POST['action'] == 'remove') {
            $product_id = (int)$_POST['product_id'];
            unset($_SESSION['cart'][$product_id]);
        } elseif ($_POST['action'] == 'checkout' && !empty($_SESSION['cart'])) {
            $user_id = $_SESSION['user_id'];
            
            // Calculate total first and verify stock
            $total_amount = 0;
            $items_to_insert = [];
            $can_checkout = true;
            
            foreach ($_SESSION['cart'] as $pid => $qty) {
                $pid = (int)$pid;
                $res = $conn->query("SELECT price, stock_quantity, name FROM products WHERE id = $pid FOR UPDATE");
                if ($res->num_rows > 0) {
                    $row = $res->fetch_assoc();
                    if ($qty > $row['stock_quantity']) {
                        $error_msg = "Not enough stock for " . $row['name'];
                        $can_checkout = false;
                        break;
                    }
                    $total_amount += $row['price'] * $qty;
                    $items_to_insert[] = [
                        'product_id' => $pid,
                        'quantity' => $qty,
                        'price' => $row['price']
                    ];
                }
            }
            
            if ($can_checkout) {
                $conn->begin_transaction();
                try {
                    // Create Order
                    $stmt = $conn->prepare("INSERT INTO orders (user_id, total_amount, status) VALUES (?, ?, 'pending')");
                    $final_total = $total_amount * 1.08;
                    $stmt->bind_param("id", $user_id, $final_total);
                    $stmt->execute();
                    $order_id = $conn->insert_id;
                    $stmt->close();
                    
                    // Add items & update stock
                    $item_stmt = $conn->prepare("INSERT INTO order_items (order_id, product_id, quantity, price) VALUES (?, ?, ?, ?)");
                    $upd_stmt = $conn->prepare("UPDATE products SET stock_quantity = stock_quantity - ? WHERE id = ?");
                    
                    foreach ($items_to_insert as $item) {
                        $item_stmt->bind_param("iiid", $order_id, $item['product_id'], $item['quantity'], $item['price']);
                        $item_stmt->execute();
                        
                        $upd_stmt->bind_param("ii", $item['quantity'], $item['product_id']);
                        $upd_stmt->execute();
                    }
                    $item_stmt->close();
                    $upd_stmt->close();
                    
                    $conn->commit();
                    $_SESSION['cart'] = []; // Clear cart
                    $success_msg = "Order placed successfully! Redirecting...";
                    echo "<script>setTimeout(()=>window.location='orders.php', 2000);</script>";
                } catch (Exception $e) {
                    $conn->rollback();
                    $error_msg = "Order failed: " . $e->getMessage();
                }
            }
        }
    }
}

// Fetch Cart items Data
$cart_items = [];
$total_cost = 0;

if (!empty($_SESSION['cart'])) {
    $ids = implode(',', array_map('intval', array_keys($_SESSION['cart'])));
    $res = $conn->query("SELECT id, name, price, stock_quantity FROM products WHERE id IN ($ids)");
    while ($row = $res->fetch_assoc()) {
        $qty = $_SESSION['cart'][$row['id']];
        $row['qty'] = $qty;
        $row['subtotal'] = $row['price'] * $qty;
        $total_cost += $row['subtotal'];
        $cart_items[] = $row;
    }
}
?>

<div class="page-header">
    <h1 style="font-size: 1.5rem; font-weight: 700;">Shopping Cart</h1>
</div>

<?php if ($success_msg): ?>
    <div class="alert alert-success"><?php echo $success_msg; ?></div>
<?php endif; ?>
<?php if ($error_msg): ?>
    <div class="alert alert-error"><?php echo $error_msg; ?></div>
<?php endif; ?>

<?php if (empty($cart_items)): ?>
    <div style="text-align: center; padding: 4rem 2rem; background: var(--surface); border-radius: 1rem;">
        <svg style="width: 64px; height: 64px; margin: 0 auto; color: var(--text-muted);" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3 3h2l.4 2M7 13h10l4-8H5.4M7 13L5.4 5M7 13l-2.293 2.293c-.63.63-.184 1.707.707 1.707H17m0 0a2 2 0 100 4 2 2 0 000-4zm-8 2a2 2 0 11-4 0 2 2 0 014 0z"></path></svg>
        <h2 style="font-size: 1.5rem; margin-top: 1rem; color: var(--text-main);">Your cart is empty</h2>
        <p style="color: var(--text-muted); margin-bottom: 2rem;">Looks like you haven't added anything to your cart yet.</p>
        <a href="products.php" class="btn btn-primary" style="width: auto;">Start Shopping</a>
    </div>
<?php else: ?>
    <div style="display: flex; gap: 2rem; align-items: flex-start; flex-wrap: wrap;">
        <!-- Cart Items -->
        <div class="card" style="flex: 2; min-width: 300px;">
            <h2 style="font-size: 1.25rem; font-weight: 600; margin-bottom: 1.5rem; border-bottom: 1px solid var(--border); padding-bottom: 0.5rem;">Items in your Cart</h2>
            
            <table style="width: 100%; border-collapse: collapse;">
                <tbody>
                    <?php foreach ($cart_items as $item): ?>
                        <tr style="border-bottom: 1px solid var(--border);">
                            <td style="padding: 1rem 0;">
                                <h4 style="font-size: 1rem; font-weight: 600;"><?php echo htmlspecialchars($item['name']); ?></h4>
                                <span style="font-size: 0.875rem; color: var(--text-muted);">Price: $<?php echo number_format($item['price'], 2); ?></span>
                            </td>
                            <td style="padding: 1rem 0;">
                                <form action="" method="POST" style="display: flex; gap: 0.5rem; align-items: center;">
                                    <input type="hidden" name="action" value="update">
                                    <input type="hidden" name="product_id" value="<?php echo $item['id']; ?>">
                                    <input type="number" name="quantity" value="<?php echo $item['qty']; ?>" min="1" max="<?php echo $item['stock_quantity']; ?>" class="form-input" style="width: 70px; padding: 0.25rem 0.5rem;">
                                    <button type="submit" class="btn" style="background:#f3f4f6; color:#374151; padding:0.25rem 0.5rem; width:auto;">Update</button>
                                </form>
                            </td>
                            <td style="padding: 1rem 0; font-weight: 600;">$<?php echo number_format($item['subtotal'], 2); ?></td>
                            <td style="padding: 1rem 0; text-align: right;">
                                <form action="" method="POST">
                                    <input type="hidden" name="action" value="remove">
                                    <input type="hidden" name="product_id" value="<?php echo $item['id']; ?>">
                                    <button type="submit" class="btn" style="background:transparent; color:var(--danger); padding: 0; width: auto;"><svg style="width:20px;height:20px;" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16"></path></svg></button>
                                </form>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
        
        <!-- Cart Summary -->
        <div class="card" style="flex: 1; min-width: 250px; background: #F9FAFB;">
            <h2 style="font-size: 1.25rem; font-weight: 600; margin-bottom: 1.5rem; border-bottom: 1px solid var(--border); padding-bottom: 0.5rem;">Order Summary</h2>
            
            <div style="display: flex; justify-content: space-between; margin-bottom: 1rem; color: var(--text-muted);">
                <span>Subtotal</span>
                <span>$<?php echo number_format($total_cost, 2); ?></span>
            </div>
            <div style="display: flex; justify-content: space-between; margin-bottom: 1rem; color: var(--text-muted);">
                <span>Estimated Tax (8%)</span>
                <span>$<?php echo number_format($total_cost * 0.08, 2); ?></span>
            </div>
            
            <div style="display: flex; justify-content: space-between; margin-top: 1rem; padding-top: 1rem; border-top: 1px solid var(--border); font-weight: 700; font-size: 1.25rem; margin-bottom: 2rem;">
                <span>Total</span>
                <span>$<?php echo number_format($total_cost * 1.08, 2); ?></span>
            </div>
            
            <form action="" method="POST">
                <input type="hidden" name="action" value="checkout">
                <button type="submit" class="btn btn-primary" style="font-size: 1.125rem; padding: 1rem;">Proceed to Checkout</button>
            </form>
        </div>
    </div>
<?php endif; ?>

<?php include 'user_footer.php'; ?>
