<?php
include 'user_header.php';

if (!isset($_GET['id'])) {
    header('Location: orders.php');
    exit;
}

$order_id = (int)$_GET['id'];
$user_id = $_SESSION['user_id'];

// Fetch order details ensuring it belongs to current user
$order_query = $conn->query("
    SELECT id, total_amount, status, created_at 
    FROM orders 
    WHERE id = $order_id AND user_id = $user_id
");

if ($order_query->num_rows == 0) {
    echo "Order not found or unauthorized.";
    include 'user_footer.php';
    exit;
}
$order = $order_query->fetch_assoc();

// Fetch order items
$items_query = $conn->query("
    SELECT oi.quantity, oi.price, p.name 
    FROM order_items oi 
    JOIN products p ON oi.product_id = p.id 
    WHERE oi.order_id = $order_id
");
?>

<div class="page-header">
    <h1 style="font-size: 1.5rem; font-weight: 700;">Order Details #<?php echo $order['id']; ?></h1>
    <div>
        <a href="orders.php" class="btn" style="background:#f3f4f6; color:#374151; width:auto; text-decoration:none;">Back to Orders</a>
    </div>
</div>

<div class="card" style="margin-bottom: 2rem;">
    <h3 style="margin-bottom: 1rem; border-bottom: 1px solid var(--border); padding-bottom: 0.5rem;">Order Information</h3>
    <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 1rem;">
        <div>
            <p style="margin-bottom: 0.5rem;"><span style="color:var(--text-muted);">Date Placed:</span> <br><strong><?php echo date('F d, Y h:i A', strtotime($order['created_at'])); ?></strong></p>
            <p><span style="color:var(--text-muted);">Status:</span> <br><span class="badge badge-<?php echo strtolower($order['status']); ?>" style="margin-top: 0.25rem; display:inline-block;"><?php echo ucfirst($order['status']); ?></span></p>
        </div>
        <div style="text-align: right;">
            <p style="margin-bottom: 0.5rem;"><span style="color:var(--text-muted);">Order Total:</span> <br><strong style="font-size: 1.25rem; color:var(--primary);">$<?php echo number_format($order['total_amount'], 2); ?></strong></p>
        </div>
    </div>
</div>

<h3 style="margin-bottom: 1rem; font-size: 1.125rem;">Items in Order</h3>
<div class="table-container">
    <table>
        <thead>
            <tr>
                <th>Product Name</th>
                <th>Price Each</th>
                <th>Quantity</th>
                <th style="text-align: right;">Subtotal</th>
            </tr>
        </thead>
        <tbody>
            <?php 
            $subtotal_sum = 0;
            while($item = $items_query->fetch_assoc()): 
                $item_total = $item['price'] * $item['quantity'];
                $subtotal_sum += $item_total;
            ?>
                <tr>
                    <td><strong><?php echo htmlspecialchars($item['name']); ?></strong></td>
                    <td>$<?php echo number_format($item['price'], 2); ?></td>
                    <td><?php echo $item['quantity']; ?></td>
                    <td style="text-align: right;">$<?php echo number_format($item_total, 2); ?></td>
                </tr>
            <?php endwhile; ?>
        </tbody>
        <tfoot style="background: #F9FAFB;">
            <tr>
                <td colspan="3" style="text-align: right; font-weight: 500; color:var(--text-muted);">Subtotal:</td>
                <td style="text-align: right;">$<?php echo number_format($subtotal_sum, 2); ?></td>
            </tr>
            <tr>
                <td colspan="3" style="text-align: right; font-weight: 500; color:var(--text-muted);">Tax (8%):</td>
                <td style="text-align: right;">$<?php echo number_format($subtotal_sum * 0.08, 2); ?></td>
            </tr>
            <tr style="border-top: 1px solid var(--border);">
                <td colspan="3" style="text-align: right; font-weight: 700;">Total:</td>
                <td style="text-align: right; font-weight: 700; color:var(--primary);">$<?php echo number_format($order['total_amount'], 2); ?></td>
            </tr>
        </tfoot>
    </table>
</div>

<?php include 'user_footer.php'; ?>
