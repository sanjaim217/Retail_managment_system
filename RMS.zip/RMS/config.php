<?php
$host = "localhost"; // Change if needed
$username = "root"; // Change according to your MySQL settings
$password = ""; // Change according to your MySQL settings
$database = "retail_management_db";

$conn = new mysqli($host, $username, $password, $database);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
?>
