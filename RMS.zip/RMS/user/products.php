<?php
include 'user_header.php';

$success_msg = '';

if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['action']) && $_POST['action'] == 'add_to_cart') {
    $product_id = (int)$_POST['product_id'];
    $quantity = (int)$_POST['quantity'];

    if (!isset($_SESSION['cart'])) {
        $_SESSION['cart'] = [];
    }

    if (isset($_SESSION['cart'][$product_id])) {
        $_SESSION['cart'][$product_id] += $quantity;
    } else {
        $_SESSION['cart'][$product_id] = $quantity;
    }
    
    $success_msg = "Product added to cart successfully.";
    
    // Update cart count for header
    $cart_count = count($_SESSION['cart']);
}

// Fetch products
$products = $conn->query("SELECT * FROM products WHERE stock_quantity > 0 ORDER BY id DESC");
?>

<div class="page-header">
    <h1 style="font-size: 1.5rem; font-weight: 700;">Shop Products</h1>
</div>

<?php if ($success_msg): ?>
    <div class="alert alert-success"><?php echo $success_msg; ?></div>
<?php endif; ?>

<div style="display:grid; grid-template-columns: repeat(auto-fill, minmax(280px, 1fr)); gap: 1.5rem;">
    <?php if($products->num_rows > 0): ?>
        <?php while($row = $products->fetch_assoc()): ?>
            <div class="card" style="display:flex; flex-direction:column; justify-content:space-between; height:100%;">
                <div>
                    <h3 style="font-size: 1.25rem; font-weight:600; margin-bottom:0.5rem; color:var(--text-main);"><?php echo htmlspecialchars($row['name']); ?></h3>
                    <p style="color:var(--text-muted); font-size:0.875rem; margin-bottom:1rem; flex-grow:1;"><?php echo htmlspecialchars($row['description']); ?></p>
                </div>
                <div>
                    <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:1rem;">
                        <span style="font-size:1.5rem; font-weight:700; color:var(--primary);">$<?php echo number_format($row['price'], 2); ?></span>
                        <span style="font-size:0.875rem; color:var(--success); background:#D1FAE5; padding:0.25rem 0.5rem; border-radius:1rem;">In Stock: <?php echo $row['stock_quantity']; ?></span>
                    </div>
                    <form action="" method="POST" style="display:flex; gap:0.5rem;">
                        <input type="hidden" name="action" value="add_to_cart">
                        <input type="hidden" name="product_id" value="<?php echo $row['id']; ?>">
                        <input type="number" name="quantity" value="1" min="1" max="<?php echo $row['stock_quantity']; ?>" class="form-input" style="width:70px; padding:0.5rem;">
                        <button type="submit" class="btn btn-primary" style="flex:1; padding:0.5rem;">Add to Cart</button>
                    </form>
                </div>
            </div>
        <?php endwhile; ?>
    <?php else: ?>
        <p>No products currently available.</p>
    <?php endif; ?>
</div>

<?php include 'user_footer.php'; ?>
