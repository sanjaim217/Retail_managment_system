<?php
include 'admin_header.php';

// Get total users
$res = $conn->query("SELECT COUNT(*) as count FROM users WHERE role = 'user'");
$total_users = $res->fetch_assoc()['count'];

// Get total products
$res = $conn->query("SELECT COUNT(*) as count FROM products");
$total_products = $res->fetch_assoc()['count'];

// Get total orders
$res = $conn->query("SELECT COUNT(*) as count FROM orders");
$total_orders = $res->fetch_assoc()['count'];

// Get total revenue
$res = $conn->query("SELECT SUM(total_amount) as revenue FROM orders WHERE status = 'delivered'");
$total_revenue = $res->fetch_assoc()['revenue'] ?? 0;

// Get recent orders
$recent_orders = $conn->query("
    SELECT o.id, u.username, o.total_amount, o.status, o.created_at 
    FROM orders o 
    JOIN users u ON o.user_id = u.id 
    ORDER BY o.created_at DESC LIMIT 5
");
?>

<div class="page-header">
    <h1 style="font-size: 1.5rem; font-weight: 700;">Dashboard Overview</h1>
</div>

<div class="grid-cards" style="margin-bottom: 2rem;">
    <div class="card">
        <h3 class="card-title" style="color: var(--text-muted); font-size: 0.875rem; text-transform: uppercase;">Total Sales</h3>
        <p class="card-price">$<?php echo number_format($total_revenue, 2); ?></p>
    </div>
    <div class="card">
        <h3 class="card-title" style="color: var(--text-muted); font-size: 0.875rem; text-transform: uppercase;">Total Orders</h3>
        <p class="card-price" style="color: var(--text-main);"><?php echo $total_orders; ?></p>
    </div>
    <div class="card">
        <h3 class="card-title" style="color: var(--text-muted); font-size: 0.875rem; text-transform: uppercase;">Products in Inventory</h3>
        <p class="card-price" style="color: var(--text-main);"><?php echo $total_products; ?></p>
    </div>
    <div class="card">
        <h3 class="card-title" style="color: var(--text-muted); font-size: 0.875rem; text-transform: uppercase;">Registered Users</h3>
        <p class="card-price" style="color: var(--text-main);"><?php echo $total_users; ?></p>
    </div>
</div>

<h2 style="font-size: 1.25rem; margin-bottom: 1rem;">Recent Orders</h2>
<div class="table-container">
    <table>
        <thead>
            <tr>
                <th>Order ID</th>
                <th>Customer</th>
                <th>Amount</th>
                <th>Status</th>
                <th>Date</th>
            </tr>
        </thead>
        <tbody>
            <?php if($recent_orders->num_rows > 0): ?>
                <?php while($row = $recent_orders->fetch_assoc()): ?>
                    <tr>
                        <td>#<?php echo $row['id']; ?></td>
                        <td><?php echo htmlspecialchars($row['username']); ?></td>
                        <td>$<?php echo number_format($row['total_amount'], 2); ?></td>
                        <td>
                            <span class="badge badge-<?php echo strtolower($row['status']); ?>">
                                <?php echo ucfirst($row['status']); ?>
                            </span>
                        </td>
                        <td><?php echo date('M d, Y', strtotime($row['created_at'])); ?></td>
                    </tr>
                <?php endwhile; ?>
            <?php else: ?>
                <tr><td colspan="5" style="text-align: center;">No orders found.</td></tr>
            <?php endif; ?>
        </tbody>
    </table>
</div>

<?php include 'admin_footer.php'; ?>
