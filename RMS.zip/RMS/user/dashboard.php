<?php
include 'user_header.php';

$user_id = $_SESSION['user_id'];

// Get user total orders
$res = $conn->query("SELECT COUNT(*) as count FROM orders WHERE user_id = $user_id");
$total_orders = $res->fetch_assoc()['count'];

// Get pending orders
$res = $conn->query("SELECT COUNT(*) as count FROM orders WHERE user_id = $user_id AND status IN ('pending', 'processing')");
$pending_orders = $res->fetch_assoc()['count'];

// Get recent orders
$recent_orders = $conn->query("
    SELECT id, total_amount, status, created_at 
    FROM orders 
    WHERE user_id = $user_id
    ORDER BY created_at DESC LIMIT 5
");
?>

<div class="page-header">
    <h1 style="font-size: 1.5rem; font-weight: 700;">My Dashboard</h1>
</div>

<div class="grid-cards" style="margin-bottom: 2rem;">
    <div class="card">
        <h3 class="card-title" style="color: var(--text-muted); font-size: 0.875rem; text-transform: uppercase;">My Total Orders</h3>
        <p class="card-price" style="color: var(--text-main);"><?php echo $total_orders; ?></p>
    </div>
    <div class="card">
        <h3 class="card-title" style="color: var(--text-muted); font-size: 0.875rem; text-transform: uppercase;">Pending Orders</h3>
        <p class="card-price" style="color: var(--secondary);"><?php echo $pending_orders; ?></p>
    </div>
    <div class="card">
        <h3 class="card-title" style="color: var(--text-muted); font-size: 0.875rem; text-transform: uppercase;">Items in Cart</h3>
        <p class="card-price" style="color: var(--text-main);"><?php echo $cart_count; ?></p>
    </div>
</div>

<div style="display:flex; justify-content:space-between; align-items:center; margin-bottom: 1rem;">
    <h2 style="font-size: 1.25rem;">Recent Orders</h2>
    <a href="orders.php" style="color:var(--primary); text-decoration:none; font-weight:500;">View All</a>
</div>

<div class="table-container">
    <table>
        <thead>
            <tr>
                <th>Order ID</th>
                <th>Amount</th>
                <th>Status</th>
                <th>Date</th>
            </tr>
        </thead>
        <tbody>
            <?php if($recent_orders->num_rows > 0): ?>
                <?php while($row = $recent_orders->fetch_assoc()): ?>
                    <tr>
                        <td><a href="order_details.php?id=<?php echo $row['id']; ?>" style="color:var(--primary); font-weight:500;">#<?php echo $row['id']; ?></a></td>
                        <td>$<?php echo number_format($row['total_amount'], 2); ?></td>
                        <td>
                            <span class="badge badge-<?php echo strtolower($row['status']); ?>">
                                <?php echo ucfirst($row['status']); ?>
                            </span>
                        </td>
                        <td><?php echo date('M d, Y', strtotime($row['created_at'])); ?></td>
                    </tr>
                <?php endwhile; ?>
            <?php else: ?>
                <tr><td colspan="4" style="text-align: center;">You have not placed any orders yet.</td></tr>
            <?php endif; ?>
        </tbody>
    </table>
</div>

<div style="margin-top: 2rem; background:linear-gradient(135deg, var(--primary) 0%, #764ba2 100%); color:white; padding:2rem; border-radius:1rem; text-align:center;">
    <h2 style="margin-bottom:1rem; font-size:1.5rem;">Ready to shop?</h2>
    <p style="margin-bottom:1.5rem; opacity:0.9;">Browse our catalog and find the best products for you.</p>
    <a href="products.php" class="btn" style="background:white; color:var(--primary); display:inline-block; width:auto; text-decoration:none;">Go to Shop</a>
</div>

<?php include 'user_footer.php'; ?>
