<?php
include 'admin_header.php';

$success_msg = '';
$error_msg = '';

// Handle add/edit product
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['action'])) {
    $name = $conn->real_escape_string($_POST['name']);
    $description = $conn->real_escape_string($_POST['description']);
    $price = (float)$_POST['price'];
    $stock_quantity = (int)$_POST['stock_quantity'];

    if ($_POST['action'] == 'add') {
        $sql = "INSERT INTO products (name, description, price, stock_quantity) VALUES ('$name', '$description', $price, $stock_quantity)";
        if ($conn->query($sql)) {
            $success_msg = "Product added successfully.";
        } else {
            $error_msg = "Error adding product.";
        }
    } elseif ($_POST['action'] == 'edit' && isset($_POST['id'])) {
        $id = (int)$_POST['id'];
        $sql = "UPDATE products SET name='$name', description='$description', price=$price, stock_quantity=$stock_quantity WHERE id = $id";
        if ($conn->query($sql)) {
            $success_msg = "Product updated successfully.";
        } else {
            $error_msg = "Error updating product.";
        }
    }
}

// Handle delete product
if (isset($_GET['delete'])) {
    $id = (int)$_GET['delete'];
    if ($conn->query("DELETE FROM products WHERE id = $id")) {
        $success_msg = "Product deleted successfully.";
    } else {
        $error_msg = "Error deleting product.";
    }
}

// Fetch products
$products = $conn->query("SELECT * FROM products ORDER BY id DESC");
?>

<div class="page-header">
    <h1 style="font-size: 1.5rem; font-weight: 700;">Inventory Management</h1>
    <button class="btn btn-primary" style="width: auto;" onclick="document.getElementById('add-modal').style.display='block'">+ Add Product</button>
</div>

<?php if ($success_msg): ?>
    <div class="alert alert-success"><?php echo $success_msg; ?></div>
<?php endif; ?>
<?php if ($error_msg): ?>
    <div class="alert alert-error"><?php echo $error_msg; ?></div>
<?php endif; ?>

<div class="table-container">
    <table>
        <thead>
            <tr>
                <th>ID</th>
                <th>Name</th>
                <th>Price</th>
                <th>Stock</th>
                <th>Actions</th>
            </tr>
        </thead>
        <tbody>
            <?php if($products->num_rows > 0): ?>
                <?php while($row = $products->fetch_assoc()): ?>
                    <tr>
                        <td><?php echo $row['id']; ?></td>
                        <td>
                            <strong><?php echo htmlspecialchars($row['name']); ?></strong><br>
                            <small style="color: var(--text-muted);"><?php echo htmlspecialchars($row['description']); ?></small>
                        </td>
                        <td>$<?php echo number_format($row['price'], 2); ?></td>
                        <td><?php echo $row['stock_quantity']; ?></td>
                        <td>
                            <button class="btn" style="background:#f3f4f6; color:#374151; padding:0.25rem 0.5rem; width:auto; font-size:0.875rem;" onclick='editProduct(<?php echo json_encode($row); ?>)'>Edit</button>
                            <a href="inventory.php?delete=<?php echo $row['id']; ?>" class="btn btn-danger" style="padding:0.25rem 0.5rem; width:auto; font-size:0.875rem;" onclick="return confirm('Are you sure you want to delete this product?');">Delete</a>
                        </td>
                    </tr>
                <?php endwhile; ?>
            <?php else: ?>
                <tr><td colspan="5" style="text-align: center;">No products found.</td></tr>
            <?php endif; ?>
        </tbody>
    </table>
</div>

<!-- Add/Edit Modal (Simple inline implementation) -->
<div id="add-modal" style="display:none; position:fixed; top:0; left:0; width:100%; height:100%; background:rgba(0,0,0,0.5); align-items:center; justify-content:center; z-index:50;">
    <div style="background:var(--surface); padding:2rem; border-radius:1rem; width:100%; max-width:500px; margin: 10% auto;">
        <h2 id="modal-title" style="margin-bottom:1.5rem;">Add Product</h2>
        <form action="" method="POST" id="productForm">
            <input type="hidden" name="action" id="form-action" value="add">
            <input type="hidden" name="id" id="form-id" value="">
            
            <div class="form-group">
                <label class="form-label">Name</label>
                <input class="form-input" type="text" name="name" id="form-name" required>
            </div>
            
            <div class="form-group">
                <label class="form-label">Description</label>
                <textarea class="form-input" name="description" id="form-desc" rows="3" required></textarea>
            </div>
            
            <div style="display:flex; gap:1rem;">
                <div class="form-group" style="flex:1;">
                    <label class="form-label">Price</label>
                    <input class="form-input" type="number" step="0.01" name="price" id="form-price" required>
                </div>
                <div class="form-group" style="flex:1;">
                    <label class="form-label">Stock Quantity</label>
                    <input class="form-input" type="number" name="stock_quantity" id="form-stock" required>
                </div>
            </div>
            
            <div style="display:flex; gap:1rem; margin-top:1rem;">
                <button type="submit" class="btn btn-primary">Save</button>
                <button type="button" class="btn" style="background:#E5E7EB; color:#374151;" onclick="closeModal()">Cancel</button>
            </div>
        </form>
    </div>
</div>

<script>
function editProduct(product) {
    document.getElementById('modal-title').innerText = 'Edit Product';
    document.getElementById('form-action').value = 'edit';
    document.getElementById('form-id').value = product.id;
    document.getElementById('form-name').value = product.name;
    document.getElementById('form-desc').value = product.description;
    document.getElementById('form-price').value = product.price;
    document.getElementById('form-stock').value = product.stock_quantity;
    document.getElementById('add-modal').style.display = 'block';
}

function closeModal() {
    document.getElementById('add-modal').style.display = 'none';
    document.getElementById('productForm').reset();
    document.getElementById('modal-title').innerText = 'Add Product';
    document.getElementById('form-action').value = 'add';
}
</script>

<?php include 'admin_footer.php'; ?>
