CREATE DATABASE IF NOT EXISTS retail_management_db;
USE retail_management_db;

CREATE TABLE `users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(50) NOT NULL,
  `password` varchar(255) NOT NULL,
  `role` enum('admin','user') NOT NULL DEFAULT 'user',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `username` (`username`)
);

CREATE TABLE `products` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `description` text,
  `price` decimal(10,2) NOT NULL,
  `stock_quantity` int(11) NOT NULL DEFAULT 0,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
);

CREATE TABLE `orders` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `total_amount` decimal(10,2) NOT NULL,
  `status` enum('pending','processing','shipped','delivered','cancelled') NOT NULL DEFAULT 'pending',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  FOREIGN KEY (`user_id`) REFERENCES `users`(`id`) ON DELETE CASCADE
);

CREATE TABLE `order_items` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `order_id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `quantity` int(11) NOT NULL,
  `price` decimal(10,2) NOT NULL,
  PRIMARY KEY (`id`),
  FOREIGN KEY (`order_id`) REFERENCES `orders`(`id`) ON DELETE CASCADE,
  FOREIGN KEY (`product_id`) REFERENCES `products`(`id`) ON DELETE CASCADE
);

-- Insert default admin user (password: admin123)
-- Hash generated using PHP's password_hash('admin123', PASSWORD_DEFAULT)
INSERT INTO `users` (`username`, `password`, `role`) VALUES
('admin', '$2y$10$oDgbLlBIDkYKbfi93i2bluR6mV1J6mPA88DNZlzl6f0G5CdDI7gwu', 'admin'),
('user', '$2y$10$oDgbLlBIDkYKbfi93i2bluR6mV1J6mPA88DNZlzl6f0G5CdDI7gwu', 'user');

-- Insert some dummy products
INSERT INTO `products` (`name`, `description`, `price`, `stock_quantity`) VALUES
('Laptop Pro 15', 'High performance laptop for professionals', 1299.99, 50),
('Wireless Mouse', 'Ergonomic wireless mouse with fast scrolling', 29.99, 200),
('Mechanical Keyboard', 'RGB mechanical keyboard with tactile switches', 89.99, 100),
('27-inch Monitor', '4K UHD IPS display monitor', 349.99, 30);
