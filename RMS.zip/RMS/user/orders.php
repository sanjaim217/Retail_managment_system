<?php
include 'user_header.php';

$user_id = $_SESSION['user_id'];

// Fetch orders
$orders = $conn->query("
    SELECT id, total_amount, status, created_at 
    FROM orders 
    WHERE user_id = $user_id 
    ORDER BY created_at DESC
");
?>

<div class="page-header">
    <h1 style="font-size: 1.5rem; font-weight: 700;">My Orders</h1>
</div>

<div class="table-container">
    <table>
        <thead>
            <tr>
                <th>Order ID</th>
                <th>Total Amount</th>
                <th>Status</th>
                <th>Date Placed</th>
                <th>Action</th>
            </tr>
        </thead>
        <tbody>
            <?php if($orders->num_rows > 0): ?>
                <?php while($row = $orders->fetch_assoc()): ?>
                    <tr>
                        <td><strong>#<?php echo $row['id']; ?></strong></td>
                        <td>$<?php echo number_format($row['total_amount'], 2); ?></td>
                        <td>
                            <span class="badge badge-<?php echo strtolower($row['status']); ?>">
                                <?php echo ucfirst($row['status']); ?>
                            </span>
                        </td>
                        <td><?php echo date('M d, Y h:i A', strtotime($row['created_at'])); ?></td>
                        <td>
                            <a href="order_details.php?id=<?php echo $row['id']; ?>" class="btn" style="background:#f3f4f6; color:#374151; padding:0.25rem 0.5rem; font-size:0.875rem;">View Details</a>
                        </td>
                    </tr>
                <?php endwhile; ?>
            <?php else: ?>
                <tr><td colspan="5" style="text-align: center; padding: 2rem;">You haven't placed any orders yet.</td></tr>
            <?php endif; ?>
        </tbody>
    </table>
</div>

<?php include 'user_footer.php'; ?>
