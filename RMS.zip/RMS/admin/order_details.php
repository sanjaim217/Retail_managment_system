<?php
include 'admin_header.php';

if (!isset($_GET['id'])) {
    header('Location: orders.php');
    exit;
}

$order_id = (int)$_GET['id'];

// Fetch order details
$order_query = $conn->query("
    SELECT o.id, u.username, o.total_amount, o.status, o.created_at 
    FROM orders o 
    JOIN users u ON o.user_id = u.id 
    WHERE o.id = $order_id
");

if ($order_query->num_rows == 0) {
    echo "Order not found.";
    include 'admin_footer.php';
    exit;
}
$order = $order_query->fetch_assoc();

// Fetch order items
$items_query = $conn->query("
    SELECT oi.quantity, oi.price, p.name 
    FROM order_items oi 
    JOIN products p ON oi.product_id = p.id 
    WHERE oi.order_id = $order_id
");
?>

<div class="page-header">
    <h1 style="font-size: 1.5rem; font-weight: 700;">Order Details #<?php echo $order['id']; ?></h1>
    <a href="orders.php" class="btn" style="background:#f3f4f6; color:#374151; width:auto;">Back to Orders</a>
</div>

<div class="card" style="margin-bottom: 2rem;">
    <h3 style="margin-bottom: 1rem; border-bottom: 1px solid var(--border); padding-bottom: 0.5rem;">Order Information</h3>
    <p><strong>Customer:</strong> <?php echo htmlspecialchars($order['username']); ?></p>
    <p><strong>Date:</strong> <?php echo date('M d, Y h:i A', strtotime($order['created_at'])); ?></p>
    <p><strong>Status:</strong> <span class="badge badge-<?php echo strtolower($order['status']); ?>"><?php echo ucfirst($order['status']); ?></span></p>
    <p><strong>Total Amount:</strong> $<?php echo number_format($order['total_amount'], 2); ?></p>
</div>

<h3 style="margin-bottom: 1rem;">Items</h3>
<div class="table-container">
    <table>
        <thead>
            <tr>
                <th>Product Name</th>
                <th>Quantity</th>
                <th>Price Each</th>
                <th>Subtotal</th>
            </tr>
        </thead>
        <tbody>
            <?php while($item = $items_query->fetch_assoc()): ?>
                <tr>
                    <td><?php echo htmlspecialchars($item['name']); ?></td>
                    <td><?php echo $item['quantity']; ?></td>
                    <td>$<?php echo number_format($item['price'], 2); ?></td>
                    <td>$<?php echo number_format($item['price'] * $item['quantity'], 2); ?></td>
                </tr>
            <?php endwhile; ?>
        </tbody>
        <tfoot>
            <tr>
                <td colspan="3" style="text-align: right; font-weight: bold;">Total:</td>
                <td style="font-weight: bold;">$<?php echo number_format($order['total_amount'], 2); ?></td>
            </tr>
        </tfoot>
    </table>
</div>

<?php include 'admin_footer.php'; ?>
