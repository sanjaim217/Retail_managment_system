<?php
include 'admin_header.php';

$success_msg = '';
$error_msg = '';

if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['action'])) {
    $username = $conn->real_escape_string($_POST['username']);
    $role = $conn->real_escape_string($_POST['role']);
    
    if ($_POST['action'] == 'add') {
        $password = password_hash($_POST['password'], PASSWORD_DEFAULT);
        $sql = "INSERT INTO users (username, password, role) VALUES ('$username', '$password', '$role')";
        if ($conn->query($sql)) {
            $success_msg = "User added successfully.";
        } else {
            $error_msg = "Error adding user. Username may already exist.";
        }
    } elseif ($_POST['action'] == 'edit' && isset($_POST['id'])) {
        $id = (int)$_POST['id'];
        $sql = "UPDATE users SET username='$username', role='$role' WHERE id = $id";
        if ($conn->query($sql)) {
            $success_msg = "User updated successfully.";
            
            // Handle password change if provided
            if (!empty($_POST['password'])) {
                $password = password_hash($_POST['password'], PASSWORD_DEFAULT);
                $conn->query("UPDATE users SET password='$password' WHERE id = $id");
            }
        } else {
            $error_msg = "Error updating user.";
        }
    }
}

if (isset($_GET['delete'])) {
    $id = (int)$_GET['delete'];
    if ($id == $_SESSION['user_id']) {
        $error_msg = "You cannot delete yourself.";
    } else {
        if ($conn->query("DELETE FROM users WHERE id = $id")) {
            $success_msg = "User deleted successfully.";
        } else {
            $error_msg = "Error deleting user.";
        }
    }
}

// Fetch users
$users = $conn->query("SELECT id, username, role, created_at FROM users ORDER BY id DESC");
?>

<div class="page-header">
    <h1 style="font-size: 1.5rem; font-weight: 700;">User Management</h1>
    <button class="btn btn-primary" style="width: auto;" onclick="document.getElementById('add-modal').style.display='block'">+ Add User</button>
</div>

<?php if ($success_msg): ?>
    <div class="alert alert-success"><?php echo $success_msg; ?></div>
<?php endif; ?>
<?php if ($error_msg): ?>
    <div class="alert alert-error"><?php echo $error_msg; ?></div>
<?php endif; ?>

<div class="table-container">
    <table>
        <thead>
            <tr>
                <th>ID</th>
                <th>Username</th>
                <th>Role</th>
                <th>Created At</th>
                <th>Actions</th>
            </tr>
        </thead>
        <tbody>
            <?php if($users->num_rows > 0): ?>
                <?php while($row = $users->fetch_assoc()): ?>
                    <tr>
                        <td><?php echo $row['id']; ?></td>
                        <td><?php echo htmlspecialchars($row['username']); ?></td>
                        <td><span class="badge badge-<?php echo $row['role'] == 'admin' ? 'shipped' : 'pending'; ?>"><?php echo ucfirst($row['role']); ?></span></td>
                        <td><?php echo date('M d, Y', strtotime($row['created_at'])); ?></td>
                        <td>
                            <button class="btn" style="background:#f3f4f6; color:#374151; padding:0.25rem 0.5rem; width:auto; font-size:0.875rem;" onclick='editUser(<?php echo json_encode($row); ?>)'>Edit</button>
                            <?php if($row['id'] != $_SESSION['user_id']): ?>
                                <a href="users.php?delete=<?php echo $row['id']; ?>" class="btn btn-danger" style="padding:0.25rem 0.5rem; width:auto; font-size:0.875rem;" onclick="return confirm('Are you sure you want to delete this user?');">Delete</a>
                            <?php endif; ?>
                        </td>
                    </tr>
                <?php endwhile; ?>
            <?php else: ?>
                <tr><td colspan="5" style="text-align: center;">No users found.</td></tr>
            <?php endif; ?>
        </tbody>
    </table>
</div>

<!-- Add/Edit Modal (Simple inline implementation) -->
<div id="add-modal" style="display:none; position:fixed; top:0; left:0; width:100%; height:100%; background:rgba(0,0,0,0.5); align-items:center; justify-content:center; z-index:50;">
    <div style="background:var(--surface); padding:2rem; border-radius:1rem; width:100%; max-width:400px; margin: 10% auto;">
        <h2 id="modal-title" style="margin-bottom:1.5rem;">Add User</h2>
        <form action="" method="POST" id="userForm">
            <input type="hidden" name="action" id="form-action" value="add">
            <input type="hidden" name="id" id="form-id" value="">
            
            <div class="form-group">
                <label class="form-label">Username</label>
                <input class="form-input" type="text" name="username" id="form-username" required>
            </div>
            
            <div class="form-group">
                <label class="form-label">Password <small id="pwd-help" style="color:var(--text-muted);"></small></label>
                <input class="form-input" type="password" name="password" id="form-password" required>
            </div>
            
            <div class="form-group">
                <label class="form-label">Role</label>
                <select class="form-input" name="role" id="form-role" required>
                    <option value="user">User</option>
                    <option value="admin">Admin</option>
                </select>
            </div>
            
            <div style="display:flex; gap:1rem; margin-top:1rem;">
                <button type="submit" class="btn btn-primary">Save</button>
                <button type="button" class="btn" style="background:#E5E7EB; color:#374151;" onclick="closeModal()">Cancel</button>
            </div>
        </form>
    </div>
</div>

<script>
function editUser(user) {
    document.getElementById('modal-title').innerText = 'Edit User';
    document.getElementById('form-action').value = 'edit';
    document.getElementById('form-id').value = user.id;
    document.getElementById('form-username').value = user.username;
    document.getElementById('form-role').value = user.role;
    
    document.getElementById('form-password').required = false;
    document.getElementById('pwd-help').innerText = '(Leave blank to keep current password)';
    
    document.getElementById('add-modal').style.display = 'block';
}

function closeModal() {
    document.getElementById('add-modal').style.display = 'none';
    document.getElementById('userForm').reset();
    document.getElementById('modal-title').innerText = 'Add User';
    document.getElementById('form-action').value = 'add';
    document.getElementById('form-password').required = true;
    document.getElementById('pwd-help').innerText = '';
}
</script>

<?php include 'admin_footer.php'; ?>
